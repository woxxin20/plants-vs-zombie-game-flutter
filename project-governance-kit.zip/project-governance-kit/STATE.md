# STATE — project-governance-kit

<!-- AGENT-OWNED. Whole-file rewrite only, never patched.
     Humans edit HUMAN NOTES only. Rules: .ai/STATE-PROTOCOL.md -->

CYCLE:   1 (closed)
UPDATED: 2026-08-29T15:51+05:30
BY:      agent
BRANCH:  UNKNOWN
COMMIT:  UNKNOWN
STATUS:  BLOCKED

## NEXT ACTION
Run `git init` at repo root — no git history exists yet, so BRANCH/COMMIT
here and the commit-per-write procedure in .ai/STATE-PROTOCOL.md §7 cannot
function until it does.

## PROJECT
Type:    Reusable Project Governance Kit (docs-only template); no application
         code exists in this repo yet
Phase:   Draft — every file in docs/ still carries `[REQUIRED: ...]` placeholders
Success: UNKNOWN — docs/prd.md has no product definition or success metric yet

## GOAL — this branch
Wire STATE.md Protocol v2 into this kit so it ships as part of the template.
Done when:
- [x] STATE.md, .ai/STATE-PROTOCOL.md, .ai/inbox/.gitkeep exist
- [x] .claude/settings.json (SessionStart/SessionEnd hooks) and
      .claude/commands/wrap.md exist
- [x] CLAUDE.md and AGENTS.md carry the §9 mandatory block
- [ ] Human reviews this setup and initializes git so the protocol can commit

## BROKEN NOW
- nothing — no application code exists yet; repo is an unfilled governance-kit
  template (docs/prd.md, architecture.md, rules.md, design.md are all Draft).

## DECISIONS / DO NOT TOUCH
- STATE.md now owns NEXT ACTION, BROKEN NOW, and open/closed cycle status;
  docs/memory.md keeps only durable handoff narrative — avoids two files
  claiming the same volatile truth (protocol §1).
- Canonical protocol rules live only in .ai/STATE-PROTOCOL.md; CLAUDE.md and
  AGENTS.md carry just the short §9 pointer block, not a second copy.

## NEEDS HUMAN
- [ ] No git repository at repo root. `git init` (and a first commit) is
      required before BRANCH/COMMIT can be tracked or STATE.md can be
      committed per protocol §7.
- [ ] docs/prd.md, architecture.md, rules.md, design.md still have
      `[REQUIRED: ...]` placeholders (product name, owners, stack, success
      metric) — README's readiness gate blocks production implementation
      until these are filled in.

## COST NOTES
- none yet — no code in this repo to flood context.

## HUMAN NOTES
(free text — agent copies this block through byte-for-byte)

## LOG
- 2026-08-29 | c1 | Bootstrapped STATE.md Protocol v2: STATE.md, .ai/,
  hooks, /wrap, CLAUDE.md/AGENTS.md §9 blocks added; git repo still missing
