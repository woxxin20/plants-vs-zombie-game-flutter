---
document: Architecture Blueprint
authority: System boundaries, stack, data, interfaces, dependency direction, technical decisions
status: Draft
owner: "[REQUIRED: technical owner]"
last_updated: "YYYY-MM-DD"
---

# Architecture — [REQUIRED: Product Name]

This document defines **how the system is shaped** to satisfy the approved PRD.
It must trace decisions to product or non-functional requirements. It does not
add product scope.

## 1. Architecture goals and drivers

| Driver | Source | Architectural consequence |
| --- | --- | --- |
| [Example: offline-safe critical flow] | `PRD-NFR-008` | [Local queue, conflict policy, retry behavior] |
| [Driver] | `PRD-FR-___` / `PRD-NFR-___` | [Required property] |

### Non-goals

- [Architecture capability intentionally not supported, such as multi-region or plugins.]
- [Premature scalability or abstraction explicitly avoided.]

## 2. System context

### Actors and external systems

| Actor/system | Role | Trust boundary | Protocol/SDK | Owner/SLA |
| --- | --- | --- | --- | --- |
| [Client app/user] | [Purpose] | [Trusted/untrusted] | [HTTPS/local] | [Owner] |
| [External service] | [Purpose] | [Boundary] | [API] | [Vendor] |

### Context flow

```text
[User] -> [Frontend] -> [Backend/API] -> [Database]
                         -> [Approved external service]
```

Replace this with the actual minimum topology. Every external system must have
a purpose, data classification, timeout, failure behavior, and replacement or
degradation strategy.

## 3. Chosen stack

Complete one exact choice per layer. Package policy is enforced in `rules.md`.

| Layer | Choice + version policy | Why | Alternatives rejected | Source/ADR |
| --- | --- | --- | --- | --- |
| Client/framework | `[REQUIRED]` | [Reason] | [Alternatives] | `ADR-001` |
| Language/runtime | `[REQUIRED]` | [Reason] | [Alternatives] | `ADR-001` |
| State management | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Navigation | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Backend/API | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Database | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Authentication | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| File/object storage | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Analytics/observability | `[REQUIRED or N/A]` | [Reason] | [Alternatives] | `ADR-___` |
| Deployment/hosting | `[REQUIRED]` | [Reason] | [Alternatives] | `ADR-___` |

## 4. Repository and folder structure

Use feature/domain boundaries, not an unstructured global collection of files.
Replace the example with the actual repository layout.

```text
/
├── AGENTS.md
├── docs/
├── src/                         # or lib/, app/, packages/
│   ├── app/                     # composition root, routing, global providers
│   ├── core/                    # narrow cross-cutting primitives
│   ├── features/
│   │   └── <feature>/
│   │       ├── domain/          # entities and use cases; framework-independent
│   │       ├── application/     # orchestration/state
│   │       ├── infrastructure/  # API, persistence, platform adapters
│   │       └── presentation/    # screens/components
│   └── shared/                  # genuinely reused UI/utilities only
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
└── scripts/                     # repeatable build/quality automation
```

### Dependency direction

`presentation -> application -> domain`

`infrastructure -> domain` through interfaces owned by the domain/application
layer. Domain code must not import UI, database, network, analytics, or platform
SDKs. The composition root wires implementations to interfaces.

Allowed exceptions must be recorded as an `ADR-*` and, if permanent, as a rule
in `rules.md`.

## 5. Component/module boundaries

| Module | Owns | Public interface | May depend on | Must not depend on |
| --- | --- | --- | --- | --- |
| [Module] | [Data/behavior] | [Contract] | [Modules] | [Forbidden dependencies] |

Rules:

- Every domain concept has one owning module.
- Cross-module access uses public contracts, never another module's internals.
- Shared modules contain stable cross-cutting primitives, not miscellaneous code.
- Cyclic dependencies are forbidden.
- A new top-level module requires an architecture review and updated table.

## 6. Frontend/client architecture

- **Composition/root:** [Startup, dependency injection, environment selection.]
- **Navigation:** [Router, route ownership, deep links, access guards.]
- **State model:** [Local vs feature vs server state; lifecycle and ownership.]
- **Rendering/UI:** [Component boundaries and design token source.]
- **Forms/validation:** [Where validation runs; error representation.]
- **Async states:** Every data view defines loading, empty, content, stale, partial, error, and retry behavior as applicable.
- **Offline/cache:** [Source of truth, freshness, invalidation, conflicts.]
- **Platform adapters:** [Permissions, notifications, background work, file system.]

## 7. Backend/service architecture

Write `N/A — no project backend` if true.

- **API style/versioning:** [REST/GraphQL/RPC/events; base path and version policy.]
- **Request lifecycle:** [Authentication -> authorization -> validation -> domain -> persistence -> response.]
- **Service boundaries:** [Monolith/modules/services and why.]
- **Idempotency:** [Required operations and key strategy.]
- **Background jobs:** [Queue, retries, dead-letter behavior, ownership.]
- **Rate limits/abuse:** [Limits, response behavior, observability.]
- **Error contract:** [Stable public error codes, safe messages, correlation IDs.]

### API contract template

| Operation | Requirement | Auth | Input/output schema | Errors | Idempotent | Owner |
| --- | --- | --- | --- | --- | --- | --- |
| [Operation] | `PRD-FR-___` | [Role] | [Contract link] | [Codes] | Yes/No | [Module] |

## 8. Data architecture

### Ownership and source of truth

| Entity/data set | Owner | Authoritative store | Cache/replicas | Retention | Classification |
| --- | --- | --- | --- | --- | --- |
| [Entity] | [Module] | [Store] | [Cache] | [Policy] | Public/Internal/Sensitive/Restricted |

### Entity contract template

#### [Entity]

- **Purpose / requirement:** `PRD-FR-___`
- **Identifier:** [Format, generation, mutability.]
- **Fields and invariants:** [Required values and constraints.]
- **Relationships:** [Cardinality and deletion behavior.]
- **Indexes/query patterns:** [Queries justified by requirements.]
- **Lifecycle:** [Creation, update, archive/delete.]
- **Auditability:** [Who/what/when if required.]

### Migrations and compatibility

- Schema changes require versioned, reviewable migrations.
- Destructive changes require a backup, forward migration, rollback or recovery
  plan, compatibility window, and explicit approval.
- Clients and APIs define backward/forward compatibility expectations.
- Seed data must be deterministic and contain no real secrets or personal data.

## 9. Authentication and authorization

- **Identity source:** [Provider/self-managed/N/A.]
- **Session/token lifecycle:** [Issue, refresh, expiry, revocation, storage.]
- **Authorization model:** [RBAC/ABAC/ownership; server is authoritative.]
- **Roles/capabilities:** [Matrix or contract link.]
- **Unauthenticated behavior:** [Allowed paths and safe fallback.]
- **Account recovery/deletion:** [Required user flow.]
- **Threats addressed:** [Enumeration, replay, token theft, confused deputy, privilege escalation.]

Never rely on hidden UI controls as authorization.

## 10. Data flow and failure behavior

For each critical journey in `prd.md`, describe:

### Flow [ID/title]

1. [Input originates.]
2. [Validation and authorization occur.]
3. [Domain operation runs.]
4. [Persistence/external calls occur.]
5. [Result is returned and rendered.]

- **Timeout:** [Threshold.]
- **Retry:** [Which failures, max attempts, backoff/jitter.]
- **Idempotency/duplication:** [Protection.]
- **Partial failure:** [Compensation or visible state.]
- **User recovery:** [What the user can do.]
- **Telemetry:** [Safe events/logs/metrics.]

## 11. Security and privacy architecture

- Validate all untrusted input at the boundary.
- Enforce authorization on the trusted server/domain boundary.
- Encrypt transport; define at-rest controls for sensitive data.
- Keep secrets in approved secret management, never source, logs, or client bundles.
- Redact sensitive fields from logs, crash reports, analytics, and support exports.
- Define dependency scanning, patch cadence, and vulnerability ownership.
- Document file upload limits, content validation, and storage access if uploads exist.
- Map privacy data flows to `PRD-NFR-004` and the PRD data section.

### Threat model

| Threat | Asset | Entry point | Control | Residual risk | Verification |
| --- | --- | --- | --- | --- | --- |
| [Threat] | [Asset] | [Boundary] | [Control] | [Risk] | [Test/review] |

## 12. Performance, reliability, and scale

| Requirement | Budget/SLO | Design response | Measurement |
| --- | --- | --- | --- |
| `PRD-NFR-001` | [Threshold] | [Caching/pagination/etc.] | [Tool/environment] |

- **Expected load:** [Users, requests, data volume, concurrency, growth horizon.]
- **Capacity limits:** [Known ceilings and failure behavior.]
- **Caching:** [What, where, TTL, invalidation, privacy.]
- **Pagination/streaming:** [Boundaries and stable ordering.]
- **Resilience:** [Circuit breaking, retries, degradation, recovery objectives.]
- **Backups/recovery:** [RPO, RTO, restore test cadence.]

## 13. Observability and operations

- **Logs:** [Structured fields, levels, retention, redaction.]
- **Metrics:** [Golden signals and product-critical counters.]
- **Traces/correlation:** [Critical cross-boundary flows.]
- **Crash/error reporting:** [Tool, environments, privacy filter.]
- **Alerts:** [Actionable thresholds, owner, escalation.]
- **Runbooks:** [Incident, rollback, restore, vendor outage.]
- **Feature flags/config:** [Owner, defaults, expiry, fail-safe behavior.]

## 14. Environments and delivery

| Environment | Purpose | Data policy | Access | Deployment trigger |
| --- | --- | --- | --- | --- |
| Local | Development | Synthetic only | Developer | Manual |
| Test/preview | Verification | Synthetic/anonymized | Team | Pull request/change |
| Production | Users | Governed real data | Least privilege | Approved release |

Define build reproducibility, configuration injection, migrations, rollout,
rollback, release ownership, and artifact/version naming.

## 15. Testing architecture

| Layer | Tests | Boundary replaced | Required coverage/critical cases |
| --- | --- | --- | --- |
| Domain | Unit/property | I/O adapters | Invariants and edge cases |
| Adapter | Contract/integration | External service if needed | Serialization, errors, retries |
| Feature | Integration/component | Minimal dependencies | Acceptance criteria |
| Product | E2E/smoke | None or production-like | Critical journeys only |

Tests must map to requirement IDs and validate behavior, not private
implementation details. Exact commands live in `AGENTS.md`.

## 16. Architecture decision records

Record decisions here or in `docs/adr/ADR-###-title.md`. Never delete superseded
decisions; link to the replacement.

### `ADR-001` — [Decision title]

- **Status:** Proposed / Accepted / Superseded / Rejected
- **Date/owner:** [Date, owner]
- **Drivers:** `PRD-FR-___`, `PRD-NFR-___`
- **Context:** [Forces and constraints.]
- **Options considered:** [At least two when material.]
- **Decision:** [Exact choice.]
- **Consequences:** [Benefits, costs, limitations, operational impact.]
- **Migration/rollback:** [If applicable.]
- **Rules created/changed:** `RULE-___`
- **Supersedes / superseded by:** [ADR ID or N/A]

## 17. Open architecture questions

| ID | Question | Options | Impact | Owner | Due/blocks |
| --- | --- | --- | --- | --- | --- |
| `ARCH-Q-001` | [Question] | [Options] | [Scope/security/cost/etc.] | [Owner] | [Phase/task] |

## 18. Change log

| Date | ADR/sections | Reason | PRD/rule/plan links | Owner |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial blueprint | [IDs] | [Owner] |

