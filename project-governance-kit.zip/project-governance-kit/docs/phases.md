---
document: Project Phases and Milestone Gates
authority: Build sequence, milestone scope, entry/exit criteria, release gates
status: Draft
owner: "[REQUIRED: delivery owner]"
last_updated: "YYYY-MM-DD"
---

# Phases — [REQUIRED: Product Name]

Phases describe **testable outcomes**, not weeks of activity. A phase is complete
only when its exit gate has objective evidence. Concrete coding tasks live in
`implementation_plan.md`.

## 1. Status and gate policy

Allowed phase status: `Not started`, `In progress`, `Blocked`, `Gate review`,
`Complete`.

Rules:

- Only one phase should normally be `In progress`; explicitly justify overlap.
- Later discovery/spikes may run early, but later production scope does not begin
  until dependencies and gates are met.
- A calendar date does not complete a phase.
- Missing required tests, unresolved critical/high findings, unfilled relevant
  `[REQUIRED]` fields, or unapproved blocking decisions prevent completion.
- Deferring an exit criterion requires a documented exception, owner, risk,
  expiry, and task—not deletion of the criterion.

## 2. Roadmap overview

| Phase | Outcome | Key PRD scope | Depends on | Status | Exit review |
| --- | --- | --- | --- | --- | --- |
| `PH-00` | Product and technical boundaries are approved | Scope + NFRs | None | Not started | [Owner/date] |
| `PH-01` | A buildable, testable application foundation exists | Supporting | `PH-00` | Not started | [Owner/date] |
| `PH-02` | Primary end-to-end user journey works with controlled data | Must requirements | `PH-01` | Not started | [Owner/date] |
| `PH-03` | Real data, auth, integrations, and recovery are production-shaped | Integration requirements | `PH-02` | Not started | [Owner/date] |
| `PH-04` | Quality, security, accessibility, and performance gates pass | NFRs | `PH-03` | Not started | [Owner/date] |
| `PH-05` | Release is deployable, observable, supportable, and reversible | Release acceptance | `PH-04` | Not started | [Owner/date] |
| `PH-06` | Launch evidence informs the next approved iteration | Metrics/guardrails | `PH-05` | Not started | [Owner/date] |

Rename/reorder phases to fit the actual product. If authentication is a real
requirement, place it before any journey that requires identity; do not create
an “Authentication phase” merely by habit.

## 3. `PH-00` — Definition and governance

**Outcome:** The team can explain the product, boundaries, architecture, design,
rules, risks, and acceptance without relying on chat history.

### Scope

- Approve target users, core journey, in/out scope, functional requirements, NFRs, and success metrics.
- Approve stack, data ownership, dependency direction, security/privacy model, and initial ADRs.
- Approve visual direction, token foundations, responsive/accessibility targets.
- Replace all relevant required placeholders and define verification commands.
- Run baseline audit and create the first traceable implementation tasks.

### Exit gate

- [ ] PRD, architecture, rules, and design owners approve their documents.
- [ ] No blocking scope/data/security/stack question remains.
- [ ] Every MVP requirement has acceptance criteria and a phase assignment.
- [ ] Initial ADRs and package policy are accepted.
- [ ] CI/local quality commands are known and runnable.
- [ ] Baseline `AUD-*` findings are triaged.

**Evidence:** [Links to IDs, audit section, command results.]

## 4. `PH-01` — Foundation

**Outcome:** A minimal application can build, run, navigate, and be tested in
supported environments using approved architecture and design primitives.

### Typical scope

- Repository/module skeleton and composition root.
- Typed configuration and environments.
- Navigation shell and access boundaries.
- Design tokens and core components needed by `PH-02`.
- Error/reporting foundation with privacy-safe defaults.
- Test harness, lint/static analysis, CI, and deterministic fixtures.
- Authentication foundation only if required before the primary journey.

### Explicit non-goal

Do not build every shared component, generic platform, or speculative feature.

### Exit gate

- [ ] Clean setup/build succeeds from documented steps.
- [ ] Module boundaries and dependency rules are enforceable.
- [ ] Required foundation checks run in CI/local workflow.
- [ ] One representative screen/component passes responsive and accessibility checks.
- [ ] No secret or production data is required for local tests.
- [ ] Open foundation findings are below the accepted severity threshold.

**Mapped tasks:** `TASK-___`  
**Evidence:** [Audit/test/build references.]

## 5. `PH-02` — Primary vertical slice

**Outcome:** The primary `UJ-01` journey works end to end with realistic,
controlled data and demonstrates real user value.

### Scope

- The smallest coherent set of `Must` requirements for `UJ-01`.
- Domain rules, UI states, persistence/API boundary, and success feedback.
- Loading, empty, invalid, failure, retry, offline/permission states that apply.
- Requirement-linked unit, integration/component, and critical E2E coverage.

### Exit gate

- [ ] Every mapped acceptance criterion passes.
- [ ] No fake success path remains hidden behind production UI.
- [ ] User input and work are preserved/recoverable according to PRD.
- [ ] Responsive, accessibility, and visual QA pass for the slice.
- [ ] Observability can diagnose failure without exposing sensitive data.
- [ ] Audit shows end-to-end traceability from PRD to evidence.

**Mapped requirements/tasks:** `PRD-FR-___`, `TASK-___`  
**Evidence:** [References.]

## 6. `PH-03` — Production integrations and complete MVP scope

**Outcome:** All approved MVP journeys use production-shaped boundaries and
handle external-system failure safely.

### Typical scope

- Real API/database/auth/storage integrations as required.
- Remaining MVP `Must` requirements and secondary journeys.
- Migrations, compatibility, authorization, rate limits, background work.
- Idempotency, retries, timeouts, conflict resolution, degradation.
- Approved analytics and operational events for PRD metrics.

### Exit gate

- [ ] All MVP `Must` functional requirements pass in a production-like environment.
- [ ] Contract and migration tests pass.
- [ ] Authorization and data-isolation tests pass.
- [ ] External outages/timeouts have tested user and operational behavior.
- [ ] Data retention/deletion/consent behavior is verifiable where applicable.
- [ ] No critical/high integration finding remains.

## 7. `PH-04` — Quality and hardening

**Outcome:** The complete MVP meets measurable non-functional requirements and
survives realistic failure and edge conditions.

### Scope

- Security/threat-model verification.
- Accessibility and responsive device/input matrix.
- Performance/load/bundle/startup budgets.
- Reliability, restore, offline, interruption, and data-loss scenarios.
- Localization/content, visual regression, dependency/license checks.
- Defect burn-down and documentation drift repair.

### Exit gate

- [ ] Applicable `PRD-NFR-*` thresholds have evidence.
- [ ] Required device/browser/input/environment matrix passes.
- [ ] Backup/restore or recovery behavior is tested where applicable.
- [ ] No critical/high audit finding is open; accepted lower findings have owners.
- [ ] Full required test/build suite passes repeatably.
- [ ] Release candidate is reproducible from documented configuration.

## 8. `PH-05` — Release readiness and launch

**Outcome:** A versioned release can be deployed, monitored, supported, and
rolled back safely.

### Scope

- Release candidate, signing/configuration, migrations, rollout and rollback.
- Store/deployment assets, legal/privacy disclosures, support/runbooks.
- Dashboards/alerts, incident ownership, feature-flag cleanup and safe defaults.
- Final PRD release acceptance and audit.

### Exit gate

- [ ] PRD release acceptance checklist passes.
- [ ] Deployment and rollback/recovery rehearsal passes.
- [ ] Monitoring and alert routing are validated.
- [ ] Support, incident, and vendor-outage owners know the procedure.
- [ ] Production configuration contains no development/debug behavior.
- [ ] Final audit decision is `Go`, or `Conditional go` with explicit accepted risk.

## 9. `PH-06` — Post-launch validation

**Outcome:** Real evidence is compared with PRD success and guardrail metrics,
and the next scope change is intentional.

### Exit gate

- [ ] Metric instrumentation is validated against real outcomes.
- [ ] Reliability, support, retention/usage, and guardrails are reviewed for the defined window.
- [ ] Top findings and user feedback are mapped to assumptions/requirements.
- [ ] Scope/architecture/design changes are made in authoritative docs before the next plan.
- [ ] Completed session history is archived; `memory.md` remains concise.

## 10. Phase template

### `PH-##` — [Outcome title]

- **Outcome:** [Observable capability/state.]
- **Status:** [Allowed value.]
- **Owner:** [Name/role.]
- **Depends on:** `PH-__`
- **Requirements:** `PRD-FR-___`, `PRD-NFR-___`
- **In scope:** [Capabilities.]
- **Out of scope:** [Boundaries.]
- **Key risks/decisions:** [IDs.]
- **Tasks:** `TASK-___`
- **Entry criteria:** [Evidence required before start.]
- **Exit criteria:** [Binary/testable conditions.]
- **Verification:** [Commands/environments/manual protocol.]
- **Evidence:** [Filled during gate review.]
- **Deferred items:** [Owner + task + accepted risk.]

## 11. Phase change log

| Date | Phase | Scope/gate/status change | Reason | PRD/plan/audit links | Owner |
| --- | --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial roadmap | Initial planning | [IDs] | [Owner] |

