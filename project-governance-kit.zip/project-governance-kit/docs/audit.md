---
document: Implementation Reality Audit
authority: Evidence of current implementation, conformance, drift, defects, and release risk
status: Active
owner: "[REQUIRED: audit owner]"
last_updated: "YYYY-MM-DD"
---

# Audit — [REQUIRED: Product Name]

This file is the reality check. It records what the repository and running
product **actually prove**, compares that evidence with the intended product,
and creates traceable remediation. It must not be softened to match optimistic
status reports.

## 1. Audit rules

- Evidence is required. “Looks done” and “should work” are not evidence.
- Runtime/tests describe current behavior; PRD/architecture/rules/design describe intended behavior.
- A mismatch is a finding, not an automatic change to the specification.
- Every finding has severity, evidence, owner, remediation task, and retest result.
- Closed findings remain in the log; never delete audit history.
- The implementer may collect evidence, but release-significant exceptions should be accepted by the accountable owner.
- Audits are read-only inspections unless a separate task authorizes remediation.

## 2. Audit metadata

- **Audit date:** `[REQUIRED: YYYY-MM-DD]`
- **Auditor:** `[REQUIRED: name/agent]`
- **Repository/version:** `[REQUIRED: commit, tag, or snapshot]`
- **Environment:** `[REQUIRED: local/test/staging/production + relevant versions]`
- **Scope:** `[REQUIRED: full baseline, phase gate, task, release, or incident]`
- **Mapped phase/release:** `PH-__` / [version]
- **Previous audit:** [Date/link or None]
- **Limitations:** [Anything inaccessible or not run.]

## 3. Result vocabulary

Conformance result:

- `Pass` — requirement/rule is met with current evidence.
- `Partial` — some acceptance conditions pass; remaining behavior is explicit.
- `Fail` — behavior contradicts or does not meet the source.
- `Not implemented` — approved scope has no implementation.
- `Not applicable` — source does not apply; reason required.
- `Not verified` — evidence is unavailable or check was not run.

Finding severity:

| Severity | Definition | Default release effect |
| --- | --- | --- |
| Critical | Active exploit, severe privacy/data loss, unusable core product, irreversible corruption | Stop work/release; immediate owner |
| High | Core requirement failure, authorization weakness, major data/accessibility/reliability risk | Blocks phase/release |
| Medium | Material degraded path, maintainability/performance issue, recoverable UX failure | Must be planned; risk acceptance to defer |
| Low | Minor inconsistency, polish, low-impact debt | May defer with owner |
| Info | Observation or improvement with no current breach | Optional follow-up |

## 4. Executive reality summary

| Area | Result | Evidence summary | Highest finding |
| --- | --- | --- | --- |
| Product/functional | Not verified | [Summary] | [Severity/None] |
| Architecture/data | Not verified | [Summary] | [Severity/None] |
| Rules/code quality | Not verified | [Summary] | [Severity/None] |
| Design/accessibility | Not verified | [Summary] | [Severity/None] |
| Security/privacy | Not verified | [Summary] | [Severity/None] |
| Performance/reliability | Not verified | [Summary] | [Severity/None] |
| Tests/build/release | Not verified | [Summary] | [Severity/None] |
| Documentation/traceability | Not verified | [Summary] | [Severity/None] |

**Overall decision:** `Not assessed` / `No-go` / `Conditional go` / `Go`

**Decision basis:** [Two to five factual sentences.]

## 5. Requirement conformance matrix

Audit every in-scope `Must` requirement and applicable NFR. Reference the PRD;
do not rewrite the requirement into a weaker form.

| Requirement | Acceptance/test | Implementation evidence | Result | Finding/task |
| --- | --- | --- | --- | --- |
| `PRD-FR-001` | [Criterion/test name] | [Path, runtime observation, test result] | Not verified | `AUD-___` / `TASK-___` |
| `PRD-NFR-001` | [Threshold/benchmark] | [Measured result + environment] | Not verified | `AUD-___` / `TASK-___` |

## 6. Journey audit

| Journey | Scenario | Environment/data | Expected source | Actual evidence | Result |
| --- | --- | --- | --- | --- | --- |
| `UJ-01` | Happy path | [Context] | `PRD-FR-___` | [Observed] | Not verified |
| `UJ-01` | Error/retry | [Context] | `PRD-FR-___` | [Observed] | Not verified |

Include relevant loading, empty, invalid, duplicate, denied permission, offline,
timeout, interruption, back/cancel, and recovery scenarios.

## 7. Architecture conformance

| Check | Expected source | Evidence | Result | Finding |
| --- | --- | --- | --- | --- |
| Repository/modules match documented ownership | Architecture §4–5 | [Paths/dependency report] | Not verified | `AUD-___` |
| Dependency direction has no cycles/violations | Architecture §4 | [Analyzer] | Not verified | `AUD-___` |
| Stack and major packages match accepted ADRs | Architecture §3/16 | [Manifest/lockfile] | Not verified | `AUD-___` |
| Data ownership/schema/migrations match contract | Architecture §8 | [Schema/migration evidence] | Not verified | `AUD-___` |
| API/error/versioning contracts match | Architecture §7 | [Contract tests] | Not verified | `AUD-___` |
| Authn/authz enforce trusted-boundary policy | Architecture §9 | [Tests/review] | Not verified | `AUD-___` |
| Failure/retry/idempotency behavior matches | Architecture §10 | [Failure tests] | Not verified | `AUD-___` |
| Environments/deployment/rollback match | Architecture §14 | [Pipeline/rehearsal] | Not verified | `AUD-___` |

## 8. Rule and dependency audit

| Rule/check | Evidence | Result | Finding |
| --- | --- | --- | --- |
| `RULE-001` dependency boundaries | [Tool/review] | Not verified | `AUD-___` |
| `RULE-004` quality commands | [Command results] | Not verified | `AUD-___` |
| `RULE-006` secret/data scan | [Tool/date] | Not verified | `AUD-___` |
| `RULE-007` dependency policy | [Manifest/license/security review] | Not verified | `AUD-___` |
| Project-specific forbidden rules | [Evidence] | Not verified | `AUD-___` |

Dependency review records direct/transitive package, version, purpose, license,
known vulnerabilities, maintenance, platform/bundle impact, and replacement risk.

## 9. Design and accessibility audit

| Check | Source | Evidence/matrix | Result | Finding |
| --- | --- | --- | --- | --- |
| Approved tokens/components only | `design.md`, `RULE-UI-001/002` | [Visual/code audit] | Not verified | `AUD-___` |
| Loading/empty/error/recovery states | Screen contracts | [Scenario evidence] | Not verified | `AUD-___` |
| Compact/medium/expanded behavior | Design §8 | [Viewport evidence] | Not verified | `AUD-___` |
| Contrast/text scale/target size | Design §14 | [Tools/manual] | Not verified | `AUD-___` |
| Semantics/focus/keyboard/input alternatives | Design §14 | [Assistive-tech matrix] | Not verified | `AUD-___` |
| Reduced motion/content/localization | Design §12–13 | [Evidence] | Not verified | `AUD-___` |

Record tested platform, viewport/device, input, text scale/zoom, theme, locale,
and assistive technology so evidence can be repeated.

## 10. Security and privacy audit

| Check | Source | Evidence | Result | Finding |
| --- | --- | --- | --- | --- |
| Input validation and injection controls | Architecture §11 / rules | [Tests/review] | Not verified | `AUD-___` |
| Authentication/session handling | Architecture §9 | [Tests/review] | Not verified | `AUD-___` |
| Authorization/object isolation | Architecture §9 | [Negative tests] | Not verified | `AUD-___` |
| Secrets/storage/transport | Rules §7 | [Scan/config review] | Not verified | `AUD-___` |
| Logging/analytics/crash redaction | PRD data + Architecture §13 | [Payload review] | Not verified | `AUD-___` |
| Consent/retention/export/deletion | `PRD-NFR-004` | [Scenario evidence] | Not verified | `AUD-___` |
| Dependency/file/deep-link risks | Rules §4/7 | [Scan/tests] | Not verified | `AUD-___` |

Do not place live secrets or unnecessary sensitive values into this audit.

## 11. Performance, reliability, and operations audit

| Requirement | Environment/load | Budget/SLO | Measured | Result | Finding |
| --- | --- | --- | --- | --- | --- |
| `PRD-NFR-001` | [Device/network/load] | [Threshold] | [Value] | Not verified | `AUD-___` |

Also verify timeout, retry, idempotency, partial failure, backup/restore, offline,
interruption, monitoring, alert ownership, runbooks, deployment, and rollback.

## 12. Test and build evidence

| Date | Check/command | Scope/environment | Result | Duration/notes | Finding |
| --- | --- | --- | --- | --- | --- |
| YYYY-MM-DD | [Exact command or named protocol] | [Scope] | Pass/Fail/Not run | [Notes] | `AUD-___` |

Record skipped/flaky tests, non-determinism, untested platforms, manual-only
acceptance, and differences from production-like conditions.

## 13. Documentation and traceability drift

| Drift | Authority | Current reality | Corrective action | Task/finding |
| --- | --- | --- | --- | --- |
| [Example: documented package differs from manifest] | Architecture/ADR | [Actual] | Decide and update code or authority | `AUD-___`, `TASK-___` |

Required checks:

- Every active task links to a valid source ID.
- Every MVP requirement is assigned to a phase/task/test.
- No duplicate/conflicting truths exist across docs.
- `memory.md` matches actual task/finding state.
- Deprecated IDs link to replacements.
- Required placeholders do not remain in the active scope.

## 14. Finding template and register

### `AUD-001` — [Concise factual title]

- **Status:** Open / Accepted risk / In remediation / Ready to retest / Closed
- **Severity:** Critical / High / Medium / Low / Info
- **Detected:** [Date/audit/version]
- **Source breached:** `PRD-___`, `ADR-___`, `RULE-___`, `DS-___`, `PH-___`
- **Affected users/data/components:** [Scope.]
- **Evidence:** [Path, test, log excerpt summary, reproducible observation.]
- **Reproduction:**
  1. [Deterministic step.]
  2. [Step.]
  3. [Actual result.]
- **Expected:** [Reference authoritative acceptance; do not invent.]
- **Impact:** [Why severity is justified.]
- **Likely cause:** [Evidence-based hypothesis or “unknown”.]
- **Remediation task:** `TASK-___`
- **Owner/due:** [Owner/date.]
- **Workaround:** [Safe temporary path or None.]
- **Retest evidence:** [Filled later.]
- **Closure/acceptance owner:** [Name/date/reason.]

### Finding register

| Finding | Severity | Status | Source | Remediation | Owner/due | Retest |
| --- | --- | --- | --- | --- | --- | --- |
| `AUD-001` | [Severity] | Open | [IDs] | `TASK-___` | [Owner/date] | Pending |

## 15. Gate decision

- **Decision:** Not assessed / No-go / Conditional go / Go
- **Scope of decision:** [Task/phase/release/version.]
- **Blocking findings:** `AUD-___` / None.
- **Accepted risks:** [Finding + accepting owner + expiry] / None.
- **Required follow-up:** `TASK-___` / None.
- **Decision owner/date:** [Owner, YYYY-MM-DD.]

`Conditional go` must name every condition, monitoring signal, owner, expiry,
and rollback trigger.

## 16. Audit history

| Date | Scope/version | Decision | Open C/H/M/L | Auditor | Notes |
| --- | --- | --- | --- | --- | --- |
| YYYY-MM-DD | Baseline | Not assessed | 0/0/0/0 | [Owner] | Initial template |

