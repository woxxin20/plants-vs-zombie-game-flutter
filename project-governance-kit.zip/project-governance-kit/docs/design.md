---
document: Product Design System and Experience Contract
authority: Visual identity, interaction behavior, tokens, responsive behavior, accessibility
status: Draft
owner: "[REQUIRED: design owner]"
last_updated: "YYYY-MM-DD"
---

# Design — [REQUIRED: Product Name]

This document defines how the product should **look, feel, communicate, and
respond**. It converts product principles into implementation-ready design
rules. Product capability belongs in `prd.md`; technical structure belongs in
`architecture.md`.

## 1. Creative North Star

**Design concept:** `[REQUIRED: short memorable phrase]`

**Experience statement:**  
[REQUIRED: Describe the feeling and behavior in one paragraph. Explain what the
design helps users do, not only how it looks.]

**Three adjectives:** [Adjective] / [Adjective] / [Adjective]

**The product should feel like:** [Concrete experiential references.]

**The product must never feel like:** [Anti-reference: cluttered, generic,
gamified, bureaucratic, childish, etc.]

## 2. Design principles

Give each principle an ID so tasks and audits can trace it.

### `DS-001` — [Principle]

- **Meaning:** [What it means in this product.]
- **Do:** [Concrete UI behavior.]
- **Do not:** [Concrete anti-pattern.]
- **Product source:** `PRD-___`
- **Verification:** [Visual/interaction/accessibility check.]

Repeat for three to six principles.

## 3. Audience and usage environment

- **Primary user:** [Link to PRD persona.]
- **Typical context:** [One-handed, desktop work, outdoors, low bandwidth, etc.]
- **Likely constraints:** [Vision, motor, language, device, attention, expertise.]
- **Primary device/input:** [Touch, mouse, keyboard, assistive tech.]
- **Content density:** [Low/medium/high and why.]

## 4. References and anti-references

| Type | Product/system | Exact element to learn from | What not to copy |
| --- | --- | --- | --- |
| Reference | [App/site/system] | [Navigation, hierarchy, motion, etc.] | [Brand/look or irrelevant behavior] |
| Anti-reference | [App/site/system/pattern] | [Problem to avoid] | N/A |

References are directional, not permission to clone protected assets or create
an inconsistent collage.

## 5. Brand and color system

Use semantic tokens. Hex values alone are insufficient; define purpose and
contrast behavior. Replace all required values.

### Brand colors

| Token | Light | Dark | Purpose | Contrast requirement |
| --- | --- | --- | --- | --- |
| `color.brand.primary` | `[REQUIRED: #RRGGBB]` | `[REQUIRED]` | Primary brand/action | [Pairing + ratio] |
| `color.brand.secondary` | `[REQUIRED]` | `[REQUIRED]` | Secondary accent | [Pairing + ratio] |

### Semantic colors

| Token | Light | Dark | Usage |
| --- | --- | --- | --- |
| `color.surface.canvas` | `[REQUIRED]` | `[REQUIRED]` | Page/app background |
| `color.surface.raised` | `[REQUIRED]` | `[REQUIRED]` | Cards/sheets |
| `color.surface.overlay` | `[REQUIRED]` | `[REQUIRED]` | Modal/popover |
| `color.text.primary` | `[REQUIRED]` | `[REQUIRED]` | Primary content |
| `color.text.secondary` | `[REQUIRED]` | `[REQUIRED]` | Supporting content |
| `color.border.default` | `[REQUIRED]` | `[REQUIRED]` | Structural separation |
| `color.action.primary` | `[REQUIRED]` | `[REQUIRED]` | Primary action |
| `color.status.success` | `[REQUIRED]` | `[REQUIRED]` | Success plus icon/text |
| `color.status.warning` | `[REQUIRED]` | `[REQUIRED]` | Warning plus icon/text |
| `color.status.error` | `[REQUIRED]` | `[REQUIRED]` | Error plus icon/text |
| `color.focus` | `[REQUIRED]` | `[REQUIRED]` | Keyboard/assistive focus |

Rules:

- Components consume semantic tokens, not raw palette values.
- Status never relies on color alone.
- Every text/background and control/state pair meets the accessibility target.
- Dark mode is either fully specified and tested or explicitly out of scope in the PRD.

## 6. Typography

| Role/token | Family | Size | Line height | Weight | Tracking | Use |
| --- | --- | --- | --- | --- | --- | --- |
| `type.display` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Rare hero moments |
| `type.h1` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Screen title |
| `type.h2` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Section title |
| `type.body` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Primary reading |
| `type.body.small` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Supporting text |
| `type.label` | `[REQUIRED]` | `[REQUIRED]` | `[REQUIRED]` | [Value] | [Value] | Controls |
| `type.mono` | `[REQUIRED or N/A]` | [Value] | [Value] | [Value] | [Value] | Codes/data only |

- Support text scaling up to `[REQUIRED: target]` without clipped actions/content.
- Use no more than `[REQUIRED: number]` font families and approved weights.
- Do not use placeholder-like low-contrast text for essential information.

## 7. Spacing, shape, elevation, and icons

### Spacing scale

Base unit: `[REQUIRED: e.g., 4 px/dp]`.

| Token | Value | Typical use |
| --- | --- | --- |
| `space.1` | `[REQUIRED]` | Tight inline gap |
| `space.2` | `[REQUIRED]` | Related items |
| `space.3` | `[REQUIRED]` | Control padding |
| `space.4` | `[REQUIRED]` | Component gap |
| `space.6` | `[REQUIRED]` | Section inset |
| `space.8` | `[REQUIRED]` | Major separation |

### Shape/elevation

| Token | Value | Use |
| --- | --- | --- |
| `radius.control` | `[REQUIRED]` | Inputs/buttons |
| `radius.card` | `[REQUIRED]` | Cards/surfaces |
| `radius.modal` | `[REQUIRED]` | Dialogs/sheets |
| `elevation.1` | `[REQUIRED]` | Subtle raised surface |
| `elevation.2` | `[REQUIRED]` | Overlay/floating control |

### Iconography

- Approved source/style: `[REQUIRED: library or custom rules]`.
- Standard sizes/stroke: `[REQUIRED]`.
- Icons support labels when meaning is not universal.
- Decorative icons are hidden from assistive technologies.
- Emoji and mixed icon families are `[REQUIRED: allowed/forbidden and context]`.

## 8. Layout and responsive behavior

Define layout modes by available width/content, not brand-specific device names.

| Mode | Width | Columns/content max | Gutters | Navigation pattern |
| --- | --- | --- | --- | --- |
| Compact | `[REQUIRED]` | [Value] | [Value] | [Bottom/stacked/etc.] |
| Medium | `[REQUIRED]` | [Value] | [Value] | [Rail/split/etc.] |
| Expanded | `[REQUIRED]` | [Value] | [Value] | [Sidebar/multi-pane/etc.] |

Rules:

- Define safe-area, keyboard, orientation, text-scale, and fold behavior.
- State which panels reflow, collapse, become sheets, or remain persistent.
- Set minimum/maximum content widths; do not stretch readable text indefinitely.
- Touch and pointer targets must meet `[REQUIRED: size]`.
- Horizontal scrolling is permitted only for `[REQUIRED: specific content or never]`.

## 9. Navigation and information architecture

- **Primary destinations:** [List with product purpose.]
- **Hierarchy:** [Maximum depth and ownership.]
- **Back behavior:** [Platform/browser/deep-link expectations.]
- **Deep links:** [Supported routes and unauthenticated behavior.]
- **Current location:** [How the user knows where they are.]
- **Unsaved work:** [Leave/close confirmation and recovery.]

| Journey | Entry | Steps/screens | Success destination | Recovery path |
| --- | --- | --- | --- | --- |
| `UJ-01` | [Entry] | [Flow] | [Outcome] | [Error/back/cancel] |

## 10. Component contract

Each reusable component gets a stable `DS-*` ID.

### `DS-010` — [Component name]

- **Purpose:** [When to use.]
- **Do not use for:** [Boundary.]
- **Variants:** [Only meaningful variants.]
- **Anatomy:** [Required parts.]
- **States:** Default / hover / focus / pressed / selected / disabled / loading / error / success as applicable.
- **Content rules:** [Length, truncation, wrapping, labels.]
- **Responsive behavior:** [Compact/medium/expanded.]
- **Accessibility:** [Role, name, value, focus order, keyboard/gesture.]
- **Tokens:** [Token IDs only.]
- **Implementation primitive:** [Approved library/widget/component.]
- **Test evidence:** [Visual, semantics, interaction.]

Minimum inventory: button, input, selection control, alert/feedback, loading,
empty state, error state, card/list row, navigation, dialog/sheet, and any
domain-specific repeated pattern.

## 11. Screen template

### [Screen name] — `[Screen ID]`

- **Purpose / journey:** `UJ-__`, `PRD-FR-___`
- **Entry conditions:** [How/when it appears.]
- **Primary action:** [Exactly one unless product requires otherwise.]
- **Information hierarchy:** [Ordered content.]
- **Components:** `DS-___`
- **States:** Loading / empty / content / partial / stale / offline / permission denied / validation error / system error / success.
- **Responsive behavior:** [Per layout mode.]
- **Accessibility:** [Title/landmark, focus, announcements, scaling.]
- **Analytics:** [Only PRD-approved events, or none.]
- **Exit/recovery:** [Back, cancel, retry, resume.]

## 12. Motion and feedback

| Token | Duration/easing | Use | Reduced-motion behavior |
| --- | --- | --- | --- |
| `motion.fast` | `[REQUIRED]` | Micro feedback | [Replace/remove] |
| `motion.standard` | `[REQUIRED]` | State/layout change | [Replace/remove] |
| `motion.emphasis` | `[REQUIRED]` | Rare transition | [Replace/remove] |

- Motion explains continuity, causality, or status; it is not decoration by default.
- No essential content or action depends on animation completing.
- Haptics/audio require purpose, user control, and platform-appropriate fallback.
- Loading feedback begins within `[REQUIRED]`; long tasks show progress/cancel/recovery as defined.

## 13. Content and voice

- **Voice:** [Traits.]
- **Reading level/technical depth:** [Target.]
- **Buttons:** Use action verbs; describe outcome rather than generic “Submit”.
- **Errors:** Say what happened, what remains safe, and what the user can do next.
- **Empty states:** Explain why empty and offer the relevant next action.
- **Dates/numbers/names:** [Localization and formatting policy.]
- **Destructive actions:** Name the object and consequence; avoid ambiguous confirmation.

## 14. Accessibility baseline

- Standard/target: `[REQUIRED: e.g., WCAG 2.2 AA plus platform guidance]`.
- Color contrast: `[REQUIRED]`.
- Text scaling/zoom: `[REQUIRED]`.
- Input alternatives: [Keyboard/switch/screen reader/voice as applicable.]
- Focus order and visible focus: [Policy.]
- Dynamic announcements: [Errors, loading, success, updates.]
- Images/media: [Alt text, captions, decorative handling.]
- Motion/flashing: [Reduced motion and seizure safety.]
- Cognitive accessibility: [Plain language, consistent patterns, timeouts.]

## 15. Asset policy

- Source/ownership/license must be recorded for every external asset.
- Required formats, dimensions, compression, dark-mode variants, and naming: `[REQUIRED]`.
- Raster/vector selection must match the asset's nature and runtime performance.
- Do not ship placeholders, watermarked assets, or unlicensed brand marks.
- Asset size budgets: `[REQUIRED]`.

## 16. Design QA gate

- [ ] Screen matches its mapped PRD requirement and journey.
- [ ] Only approved tokens/components are used.
- [ ] All states and recovery paths are present.
- [ ] Compact, medium, expanded, keyboard/safe area, and text scale behavior pass as applicable.
- [ ] Contrast, semantics, focus, target size, and reduced-motion behavior pass.
- [ ] Content is final/localizable and no placeholder data remains.
- [ ] Visual regression/golden evidence is updated intentionally.
- [ ] Deviations are recorded in `audit.md`; material design changes update this file first.

## 17. Change log

| Date | DS IDs/section | Reason | PRD/task links | Owner |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial design contract | [IDs] | [Owner] |

