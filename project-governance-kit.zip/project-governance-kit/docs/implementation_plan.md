---
document: Executable Implementation Plan
authority: Current task decomposition, order, dependencies, verification, status
status: Draft
owner: "[REQUIRED: implementation owner]"
last_updated: "YYYY-MM-DD"
---

# Implementation Plan — [REQUIRED: Product Name]

This is the translation layer between specifications and code. It references
authoritative requirements, decisions, rules, and designs; it does not redefine
them.

## 1. Current objective

- **Active phase:** `PH-__`
- **Outcome for this plan:** [One testable outcome.]
- **In-scope requirements:** `PRD-FR-___`, `PRD-NFR-___`
- **Explicitly excluded:** `PRD-NS-___` and [any phase-local exclusions].
- **Target environment/release:** [Environment/version.]
- **Owner:** [Name/role.]
- **Blocking decisions/findings:** `PRD-Q-___`, `ARCH-Q-___`, `AUD-___` or `None`.

## 2. Readiness check

- [ ] Requirements are approved and have acceptance criteria.
- [ ] Applicable ADRs are accepted.
- [ ] Applicable rules and design contracts are complete.
- [ ] Dependencies, data migrations, external access, and test fixtures are available.
- [ ] Relevant required placeholders are resolved.
- [ ] Task order supports a working/testable vertical slice.
- [ ] Rollback/recovery is defined for risky changes.

If a relevant item is unchecked, only discovery/spike work may proceed unless
an explicit exception is recorded.

## 3. Status vocabulary

Task status: `Ready`, `In progress`, `Blocked`, `In review`, `Verified`,
`Deferred`, `Cancelled`.

- `Verified` requires passing evidence and synchronized docs.
- `Blocked` requires a named blocker, owner, and next resolution action.
- `Deferred` requires a reason and destination phase/release.
- Never use percentages; state what is actually complete and what remains.

## 4. Traceability/task board

| Task | Outcome | Requirement | Phase | Architecture | Rules | Design | Depends on | Verification | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `TASK-001` | [Small testable outcome] | `PRD-FR-001` | `PH-01` | `ADR-001` | `RULE-001` | `DS-010` or N/A | None | [Test/command] | Ready |

Every implementation task must trace to a requirement. Discovery, maintenance,
or remediation tasks may instead trace to an assumption, ADR question, NFR, or
audit finding, but must state the link.

## 5. Execution order

Organize work as vertical slices where possible:

1. Establish/confirm the contract and failing acceptance/regression test.
2. Implement domain behavior and invariants.
3. Implement/adapt persistence, API, and platform boundaries.
4. Implement UI and all applicable states using design contracts.
5. Add observability and safe error/recovery behavior.
6. Run targeted and broader verification.
7. Reconcile task, audit, phase, and memory documents.

Do not build an entire unverified layer before proving one end-to-end slice.

## 6. Detailed task template

### `TASK-###` — [Verb + observable outcome]

- **Status:** Ready / In progress / Blocked / In review / Verified / Deferred / Cancelled
- **Owner:** [Name/agent.]
- **Requirement:** `PRD-FR-___` / `PRD-NFR-___` / `AUD-___`
- **Phase:** `PH-__`
- **Architecture:** `ADR-___`, architecture §[section]
- **Rules:** `RULE-___`
- **Design:** `DS-___` / N/A
- **Dependencies:** `TASK-___`, external access, decision, migration.
- **Why now:** [Why this is the next smallest valuable/risk-reducing task.]

#### Scope

- [Concrete change.]
- [Concrete state/error path.]

#### Out of scope

- [Nearby work intentionally excluded.]

#### Expected file/module impact

- `[path/module]` — [responsibility/change].

Expected paths guide work but do not authorize violation of the architecture.
Update the task if discovery reveals a different valid shape.

#### Acceptance and verification

| Acceptance criterion | Test/evidence | Environment | Result |
| --- | --- | --- | --- |
| [Reference PRD criterion, do not rewrite its meaning] | [Test name/command/manual protocol] | [Local/test/etc.] | Pending |

#### Risk and rollback

- **Risk:** [Data, security, user experience, compatibility, cost.]
- **Mitigation:** [How reduced.]
- **Rollback/recovery:** [Exact safe path or N/A with reason.]

#### Completion record

- **Completed:** [Date/commit/change reference.]
- **Checks:** [Command/test and result.]
- **Audit findings resolved/created:** `AUD-___` / None.
- **Follow-ups:** `TASK-___` / None.

## 7. Cross-cutting verification matrix

| Concern | Applicable requirement/rule | Planned evidence | Task owner | Result |
| --- | --- | --- | --- | --- |
| Functional acceptance | `PRD-FR-___` | [Tests] | `TASK-___` | Pending |
| Accessibility | `PRD-NFR-005`, `RULE-UI-004` | [Tool/manual matrix] | `TASK-___` | Pending |
| Security/privacy | `PRD-NFR-003/004` | [Threat/authorization/privacy tests] | `TASK-___` | Pending |
| Performance | `PRD-NFR-001` | [Benchmark] | `TASK-___` | Pending |
| Reliability/offline | `PRD-NFR-002/008` | [Failure scenarios] | `TASK-___` | Pending |
| Responsive/visual | `DS-___` | [Viewport/golden evidence] | `TASK-___` | Pending |
| Build/release | `PH-__` gate | [Build/deploy/rollback evidence] | `TASK-___` | Pending |

## 8. Dependency and migration plan

| Change | Reason/source | Compatibility impact | Migration steps | Rollback/recovery | Task |
| --- | --- | --- | --- | --- | --- |
| [Package/schema/API/config] | [ID] | [Impact] | [Steps] | [Steps] | `TASK-___` |

## 9. Release/rollout plan

- **Release unit/version:** [Value.]
- **Pre-deploy checks:** [Exact gates.]
- **Migration order:** [If applicable.]
- **Rollout strategy:** [All-at-once, staged, feature flag; approval.]
- **Health signals:** [Metrics/logs/user behavior and thresholds.]
- **Abort conditions:** [Exact signals.]
- **Rollback/recovery:** [Exact procedure and owner.]
- **Post-release validation:** [Critical journeys and time window.]

## 10. Definition of done

A task may be marked `Verified` only when:

- [ ] It meets mapped acceptance criteria without expanding scope.
- [ ] All applicable checks from `AGENTS.md` pass.
- [ ] Tests cover success, expected failure, and relevant edge/recovery paths.
- [ ] Architecture, dependency, security, and design rules are satisfied.
- [ ] Required migration/rollback and observability are present.
- [ ] No placeholders, debug bypasses, fake production paths, or unexplained TODOs remain.
- [ ] Audit findings are updated with evidence.
- [ ] Plan, phase status if affected, and memory handoff are synchronized.

## 11. Plan change log

| Date | Task IDs | Change | Reason/source | Owner |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial executable plan | `PH-__`, `PRD-___` | [Owner] |

