---
document: Product Requirements Document
authority: Product purpose, users, scope, requirements, non-goals, success
status: Draft
owner: "[REQUIRED: product owner]"
last_updated: "YYYY-MM-DD"
---

# Product Requirements Document — [REQUIRED: Product Name]

This document defines **what** the product must accomplish and **why**. It is
the product North Star. It does not prescribe folder structure, packages, or
implementation details.

## 1. Product definition

**One-sentence product:**  
[REQUIRED: For a specific user, the product solves a specific problem by doing
a specific thing.]

**North Star outcome:**  
[REQUIRED: The durable user outcome the product should optimize, independent of
individual features.]

**Problem statement:**  
[REQUIRED: What is painful today, who experiences it, how often, and why current
alternatives are insufficient.]

**Why now:**  
[REQUIRED: User, market, regulatory, operational, or technical reason this is
worth building now.]

## 2. Users and context

### Primary user — [REQUIRED: name]

- **Profile:** [Who they are; include only traits relevant to the product.]
- **Job to be done:** When [situation], I want to [motivation], so I can [outcome].
- **Current behavior:** [How they solve it now.]
- **Pain points:** [Ranked problems, supported by evidence when available.]
- **Environment:** [Device, connectivity, accessibility, language, geography, skill.]
- **Success from their perspective:** [Observable end state.]

### Secondary user — [Optional]

- **Profile:**
- **Job to be done:**
- **Needs that differ from the primary user:**

### Explicitly not a target user

[REQUIRED: Identify audiences the first version is not designed to serve. This
prevents accidental scope expansion.]

## 3. Product principles

Use these to choose between valid solutions. Keep three to five, ordered.

1. **[REQUIRED: Principle]:** [Decision implication.]
2. **[REQUIRED: Principle]:** [Decision implication.]
3. **[REQUIRED: Principle]:** [Decision implication.]

## 4. Scope boundaries

### In scope

| ID | Capability | User value | Release |
| --- | --- | --- | --- |
| `PRD-SC-001` | [Capability] | [Why the user needs it] | MVP |

### Out of scope — what this product will not do

This section is binding. An out-of-scope item requires an explicit PRD change
before implementation.

| ID | Not included | Reason | Revisit trigger |
| --- | --- | --- | --- |
| `PRD-NS-001` | [Feature, user, platform, workflow, or integration] | [Why excluded] | [Evidence or date that could justify reconsideration] |
| `PRD-NS-002` | [Example: admin automation beyond basic moderation] | [Protect MVP focus] | [MVP usage threshold] |

### Assumptions

| ID | Assumption | Evidence | Risk if false | Validation date/method |
| --- | --- | --- | --- | --- |
| `PRD-A-001` | [Assumption] | [Known evidence or “unvalidated”] | [Impact] | [How and when to test] |

## 5. Core user journeys

### Journey `UJ-01` — [REQUIRED: Primary success journey]

- **Actor:** [User type]
- **Trigger:** [What starts the journey]
- **Preconditions:** [Required state]
- **Happy path:**
  1. [User action and visible system response.]
  2. [Next action and response.]
  3. [Successful outcome.]
- **Alternative/edge paths:** [Empty, offline, denied permission, invalid input, conflict, timeout.]
- **Failure recovery:** [How the user recovers without losing work.]
- **Completion signal:** [Observable result.]
- **Mapped requirements:** `PRD-FR-___`

Repeat for every launch-critical journey. Do not create a journey for trivial
screen navigation unless it has distinct product value.

## 6. Functional requirements

Requirements state observable behavior, not implementation. Use “must” for a
release requirement and give every requirement testable acceptance criteria.

### `PRD-FR-001` — [REQUIRED: Requirement title]

- **Statement:** The product must [observable capability].
- **User/value:** [Persona and outcome.]
- **Priority:** Must / Should / Could / Won't now
- **Journey:** `UJ-__`
- **Preconditions:** [State required before behavior starts.]
- **Acceptance criteria:**
  - Given [context], when [action], then [observable result].
  - Given [edge condition], when [action], then [safe/recoverable result].
  - Given [failure], when [retry/recovery], then [expected outcome].
- **Data involved:** [Entities/fields at a product level; no schema design.]
- **Dependencies:** [External capability or other requirement IDs.]
- **Excluded behavior:** [Nearby behavior that is intentionally not required.]

### Requirement index

| ID | Title | Priority | Journey | Release | Status |
| --- | --- | --- | --- | --- | --- |
| `PRD-FR-001` | [Title] | Must | `UJ-01` | MVP | Proposed |

Allowed status: `Proposed`, `Approved`, `Deprecated`. Implementation status
belongs in `implementation_plan.md`, not here.

## 7. Non-functional requirements

Use measurable thresholds. “Fast,” “secure,” and “scalable” are not sufficient.

| ID | Category | Requirement | Measurement / acceptance |
| --- | --- | --- | --- |
| `PRD-NFR-001` | Performance | [Critical action threshold] | [Device/network percentile and tool] |
| `PRD-NFR-002` | Reliability | [Availability/data durability requirement] | [SLO, error rate, recovery objective] |
| `PRD-NFR-003` | Security | [Authentication/authorization/data requirement] | [Threat/test/control] |
| `PRD-NFR-004` | Privacy | [Collection, consent, deletion, retention] | [Auditable behavior] |
| `PRD-NFR-005` | Accessibility | [Target standard and supported interaction] | [Example: WCAG 2.2 AA checks] |
| `PRD-NFR-006` | Compatibility | [Supported platforms/versions/viewports] | [Explicit matrix] |
| `PRD-NFR-007` | Localization | [Languages, formats, RTL if required] | [Test coverage] |
| `PRD-NFR-008` | Offline/network | [Expected degraded behavior] | [Scenario tests] |

## 8. Data, privacy, and permissions

- **User data collected:** [Required fields and purpose.]
- **Sensitive data:** [Classification; write “None” if true.]
- **Data not collected:** [Explicit boundary.]
- **Retention/deletion:** [User and system behavior.]
- **Sharing/processors:** [Product-level list and purpose.]
- **Device permissions:** [Permission, user value, fallback when denied.]
- **Consent requirements:** [When and how consent is obtained/revoked.]
- **Age/geography constraints:** [If applicable.]

Technical controls and schemas belong in `architecture.md`; enforceable coding
constraints belong in `rules.md`.

## 9. Success and guardrail metrics

| ID | Metric | Definition | Baseline | Target | Window | Source |
| --- | --- | --- | --- | --- | --- | --- |
| `PRD-SM-001` | [North Star metric] | [Exact numerator/denominator/event] | [Value/unknown] | [Value] | [Period] | [System] |
| `PRD-GM-001` | [Guardrail metric] | [Metric that must not worsen] | [Value] | [Limit] | [Period] | [System] |

Avoid vanity metrics. Every event required for measurement must map to an
approved requirement; analytics is not permission to collect unrelated data.

## 10. Business and operational constraints

- **Budget:** [Hard limits or “not yet defined”.]
- **Launch date/window:** [Date and consequence.]
- **Platforms/channels:** [Explicit release targets.]
- **Compliance/legal:** [Applicable obligations; confirm with a qualified owner.]
- **Operations/support:** [Who handles support, moderation, incidents, content.]
- **External dependencies:** [Vendor/team/system and risk.]

## 11. Risks

| ID | Risk | Likelihood | Impact | Mitigation | Owner | Trigger |
| --- | --- | --- | --- | --- | --- | --- |
| `PRD-R-001` | [Risk] | Low/Med/High | Low/Med/High | [Action] | [Owner] | [Signal] |

## 12. Open decisions

| ID | Decision needed | Options | Owner | Due | Blocks |
| --- | --- | --- | --- | --- | --- |
| `PRD-Q-001` | [Question] | [A/B/C] | [Owner] | [Date] | [Requirement/phase] |

An unresolved item that affects scope, security, cost, public API, or data is a
blocking decision, not an implementation assumption.

## 13. Release acceptance

The release is product-ready only when:

- [ ] Every MVP `Must` requirement has passing acceptance evidence.
- [ ] Every applicable non-functional threshold is met or has an explicitly accepted exception.
- [ ] No open critical/high product, security, privacy, or data-loss finding remains.
- [ ] The core journeys work for target users and supported environments.
- [ ] Analytics/measurement required by success metrics is validated without excess collection.
- [ ] Rollback, support, and ownership are defined.
- [ ] Out-of-scope behavior has not leaked into the release.

## 14. Change log

| Date | Changed IDs | Decision and reason | Approved by | Downstream docs updated |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial draft | [Owner] | Architecture / rules / design / phases / plan |

