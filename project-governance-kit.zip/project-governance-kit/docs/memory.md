---
document: Active Project Memory and Handoff
authority: Short-lived current state, recent work, blockers, bugs, and next action
status: Active
owner: "[REQUIRED: current maintainer]"
last_updated: "YYYY-MM-DD HH:MM TZ"
---

# Memory — [REQUIRED: Product Name]

> Current cycle, `NEXT ACTION`, `BROKEN NOW`, and open/closed status now live
> in [`STATE.md`](../STATE.md) at repo root — agent-owned, whole-file rewrite
> per [`.ai/STATE-PROTOCOL.md`](../.ai/STATE-PROTOCOL.md). This file keeps
> only durable handoff narrative that STATE.md's 130-line cap and 5-entry log
> have no room for.

This is the project's **working memory**, not a specification. It answers:
“Where are we now, what changed, what is blocked, and what should happen next?”

If this file conflicts with a product/architecture/rule/design source, the
authoritative source remains unchanged and the mismatch must be recorded in
`audit.md`.

## 1. Maintenance rules

- Update this file at the end of every material work session.
- Keep it concise and factual; target no more than `[REQUIRED: e.g., 200 lines]`.
- Keep only the most recent `[REQUIRED: e.g., 10]` session entries.
- Move durable product truth to `prd.md`, technical decisions to an ADR,
  constraints to `rules.md`, and visual truth to `design.md`.
- Keep the current task state in `implementation_plan.md`; summarize it here.
- Keep evidence/findings in `audit.md`; reference finding IDs here.
- Never store secrets, credentials, personal data, full logs, or long pasted chat.
- Do not erase unresolved bugs/blockers to make the project appear clean.

## 2. Current snapshot

- **Product:** [One-sentence link/summary from PRD; do not redefine.]
- **Current phase:** `PH-__` — [Status].
- **Current objective:** [From implementation plan.]
- **Active task:** `TASK-___` — [Status/outcome].
- **Last verified version:** [Commit/build/snapshot or None].
- **Overall health:** On track / At risk / Blocked — [one-sentence reason].

## 3. What is implemented and verified

List only user-visible or architecturally meaningful outcomes with evidence.

| Outcome | Requirement/task | Evidence | Verified date |
| --- | --- | --- | --- |
| [Implemented behavior] | `PRD-FR-___`, `TASK-___` | [Test/audit reference] | YYYY-MM-DD |

## 4. In progress

| Task | Current state | Remaining work | Owner | Next check |
| --- | --- | --- | --- | --- |
| `TASK-___` | [Concrete state] | [Concrete remainder] | [Owner] | [Test/review] |

## 5. Exact next actions

The single next action lives in `STATE.md` → `NEXT ACTION`. Do not maintain a
parallel list here — use this section only if a durable multi-step plan needs
more room than STATE.md's cap allows, and point to it from `NEXT ACTION`.

## 6. Blockers and decisions needed

| ID | Blocker/decision | Impact | Owner | Next action/due | Blocks |
| --- | --- | --- | --- | --- | --- |
| `PRD-Q-___` / `ARCH-Q-___` / `BLOCK-001` | [Issue] | [Impact] | [Owner] | [Action/date] | `TASK-___` |

If none, write `None`. Do not leave stale resolved blockers in this table.

## 7. Known bugs and open findings

`audit.md` owns evidence and severity. This is only the active working view.

| Finding | User/system effect | Workaround | Fix task | Status |
| --- | --- | --- | --- | --- |
| `AUD-___` | [Effect] | [Safe workaround/None] | `TASK-___` | [Status] |

## 8. Recent decisions and assumptions

Only record a short pointer. Put durable detail in the authoritative source.

| Date | Decision/assumption | Authority | Effect on current work |
| --- | --- | --- | --- |
| YYYY-MM-DD | [Summary] | `ADR-___` / `PRD-A-___` / `DS-___` | [Effect] |

## 9. Environment and operational notes

- **Active branch/worktree:** [Value.]
- **Runtime/tool versions:** [Only versions that matter now; authority is architecture/lockfile.]
- **Required local setup:** [Short pointer to setup source.]
- **Test data/mocks:** [Safe fixture state.]
- **External service status:** [Only if it affects current work.]
- **Uncommitted/user-owned changes:** [Paths/areas to preserve, or None.]

## 10. Last verification

| Date/time | Check | Result | Scope/environment | Audit link |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | [Command/test/manual protocol] | Pass/Fail/Not run | [Scope] | [Section/finding] |

If the last session did not run required checks, say so explicitly and explain
the consequence.

## 11. Recent session log

Cycle-by-cycle history now lives in `STATE.md` → `LOG` (last 5 cycles, one
line each). Use this section only for a narrative handoff that needs more
than one line — background, rationale, or context the next agent would
otherwise have to reconstruct.

Newest first. A session entry is a handoff summary, not a transcript.

### YYYY-MM-DD HH:MM TZ — [Short outcome]

- **Request/goal:** [What was attempted.]
- **Changed:** [Material files/modules/docs.]
- **IDs:** `PRD-___`, `TASK-___`, `AUD-___`.
- **Verified:** [Checks and outcome.]
- **Not verified / failed:** [Explicitly state.]
- **New findings/risks:** [IDs or None.]
- **Next:** [One exact continuation action.]

## 12. Handoff checklist

- [ ] Active phase/task and status are accurate.
- [ ] Implemented claims have evidence.
- [ ] Failed/unrun checks are visible.
- [ ] Blockers and findings link to owners/tasks.
- [ ] The exact next action is unambiguous.
- [ ] Durable decisions were promoted to their authoritative documents.
- [ ] Plan, audit, and memory agree.
- [ ] Old session entries were archived if the size limit was exceeded.

## 13. Archive pointer

Older session notes: `[REQUIRED: e.g., docs/archive/memory-YYYY-Q#.md or N/A]`.

