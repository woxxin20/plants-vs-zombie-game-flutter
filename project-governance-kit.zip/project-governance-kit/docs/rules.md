---
document: Engineering and AI Rules
authority: Non-negotiable implementation constraints, allowed and forbidden tools/patterns
status: Draft
owner: "[REQUIRED: engineering owner]"
last_updated: "YYYY-MM-DD"
---

# Rules — [REQUIRED: Product Name]

These rules convert product, architecture, security, and design decisions into
enforceable implementation boundaries. Use `MUST`, `MUST NOT`, `SHOULD`, and
`MAY` deliberately. Every hard rule has a stable ID and a verification method.

## 1. Rule hierarchy and exceptions

- Product scope comes from `prd.md`.
- System structure and approved decisions come from `architecture.md`.
- Visual behavior comes from `design.md`.
- This file is authoritative for implementation constraints.
- A rule cannot be bypassed because an implementation is faster or already exists.
- A temporary exception requires an owner, reason, affected IDs, risk, expiry date,
  and cleanup task in `implementation_plan.md`.

### Exception record

| Exception | Rule | Reason | Risk | Owner | Expires | Cleanup task |
| --- | --- | --- | --- | --- | --- | --- |
| `EX-001` | `RULE-___` | [Reason] | [Risk] | [Owner] | [Date] | `TASK-___` |

## 2. Approved baseline

Choose exact versions or a version policy. Delete examples that do not apply.

| Concern | Approved choice | Version policy | Forbidden alternatives | Source |
| --- | --- | --- | --- | --- |
| Framework | `[REQUIRED: e.g., Flutter or Next.js]` | `[REQUIRED]` | [List] | `ADR-001` |
| Language | `[REQUIRED]` | `[REQUIRED]` | [List] | `ADR-001` |
| UI system | `[REQUIRED: e.g., project widgets or shadcn/ui]` | `[REQUIRED]` | [List] | `ADR-___`, `DS-___` |
| Styling | `[REQUIRED: e.g., design tokens + ThemeExtension or Tailwind]` | `[REQUIRED]` | [List] | `DS-___` |
| State | `[REQUIRED or N/A]` | `[REQUIRED]` | [List] | `ADR-___` |
| Navigation | `[REQUIRED or N/A]` | `[REQUIRED]` | [List] | `ADR-___` |
| Networking | `[REQUIRED or N/A]` | `[REQUIRED]` | [List] | `ADR-___` |
| Persistence | `[REQUIRED or N/A]` | `[REQUIRED]` | [List] | `ADR-___` |
| Testing | `[REQUIRED]` | `[REQUIRED]` | [List] | Architecture §15 |

Examples are not defaults. A Flutter project might select Flutter SDK widgets,
Material/Cupertino primitives, a documented state solution, and tokenized
`ThemeData`; a web project might select React/Next.js, shadcn/ui, and Tailwind.
Do not mix ecosystems or add a second solution for the same concern without an
approved ADR.

## 3. Core engineering rules

| ID | Rule | Level | Verification |
| --- | --- | --- | --- |
| `RULE-001` | Code MUST follow the dependency direction and module ownership in `architecture.md`. | MUST | Static analysis + review |
| `RULE-002` | A feature MUST map to an approved `PRD-FR-*` and `TASK-*` before substantial implementation. | MUST | Plan/audit traceability |
| `RULE-003` | Public behavior MUST be covered by the smallest appropriate automated test mapped to its requirement. | MUST | Test names/metadata + CI |
| `RULE-004` | Source MUST pass the format, lint, type, test, and build commands applicable in `AGENTS.md`. | MUST | CI/local evidence |
| `RULE-005` | Errors MUST be explicit, actionable, safely logged, and recoverable where the PRD requires recovery. | MUST | Tests + review |
| `RULE-006` | Hard-coded secrets, tokens, private endpoints, credentials, or real personal data MUST NOT enter source, tests, docs, or logs. | MUST NOT | Secret scan + review |
| `RULE-007` | New dependencies MUST pass the package policy in §4. | MUST | Dependency review |
| `RULE-008` | Shared code MUST have at least two real consumers or a clear stable platform role. | MUST | Review |
| `RULE-009` | Dead code, commented-out implementations, ignored failures, and unexplained TODOs MUST NOT be committed. | MUST NOT | Lint + review |
| `RULE-010` | User-visible behavior MUST define loading, empty, error, retry, and permission/offline states when applicable. | MUST | Acceptance/UI tests |
| `RULE-011` | Data/schema/API changes MUST follow compatibility and migration rules in `architecture.md`. | MUST | Migration/contract tests |
| `RULE-012` | Documentation updates required by `README.md` MUST ship with the change. | MUST | PR/change checklist |

## 4. Dependency and package policy

Before adding a package, document:

1. Requirement and task IDs it enables.
2. Why the framework/platform cannot reasonably provide it.
3. Maintenance activity, license, security posture, release maturity, binary/bundle impact.
4. Platform support and transitive dependencies.
5. Exit/replacement strategy for critical packages.
6. Approval through an `ADR-*` when the package shapes architecture or public APIs.

### Forbidden dependency classes

- Abandoned or unmaintained packages without an owned fork/exit plan.
- Packages with incompatible or unclear licenses.
- Packages that duplicate an approved framework capability without measured need.
- Packages that require unsafe permissions or collect undeclared data.
- Packages that bypass type safety, TLS, authorization, or platform security controls.
- Multiple packages solving the same architectural concern.
- `[REQUIRED: project-specific forbidden package names]`.

All dependencies MUST be pinned according to the approved version policy and
reviewed through lockfile changes. Automated major upgrades require explicit
review and relevant test evidence.

## 5. Code organization and style

- One module owns each domain concept; cross-feature imports use public contracts.
- Domain/business logic MUST remain independent of UI, storage, network, analytics,
  and platform SDKs.
- Files and symbols MUST use `[REQUIRED: naming convention]`.
- Maximum file/function complexity is `[REQUIRED: threshold or review rule]`.
- Prefer composition and explicit data flow over hidden global state.
- Mutable global state is forbidden unless approved and encapsulated by architecture.
- Public functions/types require documentation when their contract is not obvious.
- Comments explain intent, constraints, or trade-offs—not restate code.
- Generated code MUST live in documented paths and MUST NOT be manually edited.
- Localization-ready products MUST NOT hard-code user-facing strings outside the
  approved localization system.

## 6. UI and styling rules

| ID | Rule | Verification |
| --- | --- | --- |
| `RULE-UI-001` | UI MUST use tokens from `design.md`; arbitrary colors, spacing, radii, shadows, type sizes, and animation timings are forbidden. | Lint/review/visual test |
| `RULE-UI-002` | Reuse or extend approved primitives before creating a new component. | Component inventory review |
| `RULE-UI-003` | Responsive behavior MUST follow the breakpoints/layout modes in `design.md`, not device-name checks. | Viewport/device tests |
| `RULE-UI-004` | Interactive controls MUST expose semantic labels, focus/keyboard behavior where applicable, sufficient target size, and visible states. | Accessibility tests/review |
| `RULE-UI-005` | UI MUST respect reduced motion, text scaling, contrast, and safe areas according to `design.md`. | Accessibility/visual tests |
| `RULE-UI-006` | Screens MUST NOT rely on color alone to communicate status. | Review/accessibility tests |

If the approved web stack is shadcn/ui + Tailwind, use existing shadcn
primitives and token-backed Tailwind utilities; do not add a competing CSS-in-JS
or component library. If the approved Flutter stack is used, centralize values
through the approved theme/tokens and shared widgets; do not scatter literal
styles across screens.

## 7. Data, API, and security rules

- Validate input at every untrusted boundary; client validation is usability,
  not a security boundary.
- Authorization MUST be enforced at the trusted data/service boundary for every operation.
- Use parameterized queries or approved ORM/query builders; string-built queries are forbidden.
- Public APIs MUST return stable safe error codes; internal stack traces and secrets MUST NOT be exposed.
- Network calls MUST define timeouts; retries require bounded attempts, backoff, and idempotency analysis.
- Logs/analytics MUST be allow-listed and redact sensitive values.
- Collect only PRD-approved data for a declared purpose and retention period.
- Sensitive values MUST use approved platform/server secure storage; ordinary preferences/local storage are not secure storage.
- Destructive actions require explicit confirmation proportional to impact and a recovery strategy where feasible.
- File uploads, URLs, redirects, and deep links MUST be validated against explicit allow-lists and size/type limits.

## 8. Testing rules

- Every `Must` acceptance criterion requires automated coverage unless the audit
  records why automation is infeasible and defines repeatable manual evidence.
- Unit tests cover domain rules and edge cases; integration tests cover real
  boundaries; E2E tests cover only critical user journeys.
- Tests MUST be deterministic, isolated, and independent of execution order.
- Do not use real production services, credentials, or personal data in tests.
- A bug fix MUST include a failing regression test first when technically feasible.
- Snapshots/goldens MUST assert intentional stable output, not replace behavioral tests.
- Skipped/flaky tests require an audit finding, owner, and expiry/repair task.
- Coverage is a signal, not a substitute for requirement traceability. Minimum
  policy: `[REQUIRED: coverage threshold or critical-path policy]`.

## 9. Performance and accessibility budgets

| Budget | Threshold | Requirement | Verification |
| --- | --- | --- | --- |
| [Startup/render/API/bundle] | `[REQUIRED]` | `PRD-NFR-___` | [Tool + environment] |
| Contrast | `[REQUIRED: e.g., WCAG 2.2 AA]` | `PRD-NFR-005` | [Tool/manual] |
| Touch/click target | `[REQUIRED]` | `PRD-NFR-005` | [Test/review] |

Do not optimize without measurement, but do not merge a known budget regression
without an approved exception.

## 10. Configuration and environments

- Environment behavior MUST come from typed/validated configuration, not scattered conditionals.
- Production-safe defaults are required; missing required configuration MUST fail clearly.
- Development mocks/debug menus MUST be impossible or explicitly protected in production builds.
- Feature flags MUST have owner, safe default, creation date, expiry/removal task, and analytics only if approved.
- Environment-specific endpoints and identifiers MUST NOT be inferred from branch names in application code.

## 11. Change and review rules

- Keep changes focused; unrelated refactors require separate tasks.
- Preserve user-authored/unrelated work.
- Commit/change descriptions SHOULD state requirement IDs, behavior, risk, and evidence.
- Public API, schema, framework, major dependency, security, cost, or privacy changes require an ADR and explicit review.
- Generated/binary assets require source, license/ownership, size, optimization, and accessibility metadata where applicable.
- Do not report completion while required checks fail or remain unrun.

## 12. Documentation rules

- One fact has one authoritative home; other docs link by ID.
- Dates use `YYYY-MM-DD`; status values use the enums defined in each file.
- Stable IDs are never renumbered or reused.
- Deprecated decisions remain discoverable and link to replacements.
- `memory.md` is capped at `[REQUIRED: e.g., 200 lines]`; archive old session notes rather than letting it become a second specification.
- Audit evidence includes command/test name, date, environment, and outcome.

## 13. Project-specific forbidden actions

Add exact restrictions, not vague preferences.

- `RULE-FORBID-001`: `[REQUIRED: e.g., Do not call database SDKs directly from presentation code.]`
- `RULE-FORBID-002`: `[REQUIRED: e.g., Do not introduce a second state-management package.]`
- `RULE-FORBID-003`: `[REQUIRED: e.g., Do not use dynamic/unsafe types to bypass models.]`

## 14. Rules change log

| Date | Rule IDs | Change/reason | Source ADR/PRD/design | Owner |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Initial | Initial rules | `ADR-001` | [Owner] |

